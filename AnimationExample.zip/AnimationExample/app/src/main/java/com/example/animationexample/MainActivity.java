package com.example.animationexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = findViewById(R.id.img);
    }

    public void clockwise(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.clockwise);
        img.startAnimation(anim);
    }
    public void anticlockwise(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anticlockwise);
        img.startAnimation(anim);
    }
    public void zoomin(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoom_in);
        img.startAnimation(anim);
    }
    public void zoomout(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoom_out);
        img.startAnimation(anim);
    }
    public void fadeout(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
        img.startAnimation(anim);
    }
    public void fadein(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
        img.startAnimation(anim);
    }
    public void slideup(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_up);
        img.startAnimation(anim);
    }
    public void sliddown(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_down);
        img.startAnimation(anim);
    }


}