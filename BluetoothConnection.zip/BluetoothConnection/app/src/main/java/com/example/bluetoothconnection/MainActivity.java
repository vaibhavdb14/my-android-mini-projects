package com.example.bluetoothconnection;

import
        androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private BluetoothAdapter ad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ad = BluetoothAdapter.getDefaultAdapter();
    }

   public void turnOnBluetooth(View v){
        if (ad == null){
            Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show();
        }else{
            if (!ad.isEnabled()){
                Intent enable = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enable,1);
            }else{
                Toast.makeText(this, "Bluetooth is already on", Toast.LENGTH_SHORT).show();
            }
        }
   }
   
   public void makeDiscoverable(View v){
        Intent discover = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discover.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,300);
        startActivity(discover);
   }
   
   public void listDevices(View v){
        Intent in = new Intent(this, DeviceListActivity.class);
        startActivity(in);
   }
   public void turnOffBluetooth(View v){
        if(ad != null && ad.isEnabled()){
            ad.disable();
            Toast.makeText(this, "Bluetooth tured off", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Bluetooth is already off", Toast.LENGTH_SHORT).show();
        }
   }

}