package com.example.bluetoothconnection;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Set;
public class DeviceListActivity extends AppCompatActivity {
    private ListView listView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_list);
        listView = findViewById(R.id.listView_devices);
        showPairedDevices();
    }
    private void showPairedDevices() {
        BluetoothAdapter bluetoothAdapter =
                BluetoothAdapter.getDefaultAdapter();
        Set<BluetoothDevice> pairedDevices =
                bluetoothAdapter.getBondedDevices();
//        String str[] = {"A", "B", "C"};
//        ArrayList<String> deviceList = new ArrayList<>(Array.asList(str));
        ArrayList<String> deviceList = new ArrayList<>();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                deviceList.add(device.getName() + "\n" +
                        device.getAddress());
            }
        } else {
            deviceList.add("No paired devices found");
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, deviceList);
        listView.setAdapter(adapter);
    }
}