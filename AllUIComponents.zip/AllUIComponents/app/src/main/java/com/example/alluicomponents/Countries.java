package com.example.alluicomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class Countries extends AppCompatActivity {

    TextView txtList;
    ListView lstView;
    String list[] = {"India", "America", "Brazil", "Nepal", "Spain", "France", "Portugal", "Japan", "Russia"};
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_countries);

        txtList =(TextView) findViewById(R.id.txtList);
        lstView =(ListView) findViewById(R.id.lstView);

        ArrayAdapter lstCountry = new ArrayAdapter<>(Countries.this, R.layout.activity_countries, R.id.txtList, list);
        lstView.setAdapter(lstCountry);
    }


}