package com.example.alluicomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    DatePickerDialog date;
    TimePickerDialog time;

    ProgressBar pb;

    TextView txtToast;

    EditText txtdob,txtJoiningTime;
    ToggleButton tg;
    Calendar c;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtdob=findViewById(R.id.txtdob);
        txtJoiningTime = findViewById(R.id.txtJoiningTime);
        txtToast = findViewById(R.id.toastMsg);
        tg = (ToggleButton) findViewById(R.id.btnToggle);
        pb = findViewById(R.id.progress);
    }

    public void showDateDialog(View view) {

        c =  Calendar.getInstance();

        int year=c.get(Calendar.YEAR);
        int month=c.get(Calendar.MONTH);
        int day=c.get(Calendar.DAY_OF_MONTH);

        date =new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker view, int y, int m, int d )
            {

                txtdob.setText(d+"/"+m+"/"+y);

            }
        },year,month,day);
        date.show();
    }

    public void showTimeDialog(View view) {
        c = Calendar.getInstance();

        int hour = c.get(Calendar.HOUR);
        int minute = c.get(Calendar.MINUTE);

        time = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int m) {

                txtJoiningTime.setText(hourOfDay + ":" + m);
            }
        }, hour, minute, true);
        time.show();
    }

    public void selectCounty(View view){
        startActivity(new Intent(MainActivity.this, Countries.class));
    }

    public void sendInfo(View view){

        ProgressDialog pd = new ProgressDialog(this);
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pd.setIndeterminate(false);
        pd.setProgress(0);
        pd.setMessage("Sending Info...");
        pd.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                int i =0;
                int total = 150;
                while(i<=total) {
                    i += 10;
                    pd.setProgress(i);
                    try {
                        Thread.sleep(400);
                    } catch (Exception e) {}

                    if(i>50 && i<100){
                        pd.setMessage("Little bit more...");
                    }
                    if(i==100){
                        pd.setMessage("Successfully Send!!");
                    }
                    if (i==total){pd.dismiss();}
                }
            }
        }).start();

        Toast.makeText(this, "Information is Send Successfully", Toast.LENGTH_SHORT).show();
    }

    public void toggle(View view){

        if (tg.getText().toString().equals("Applied"))
            txtToast.setText("Applied");
        else
            txtToast.setText("Denied");

        LayoutInflater lf = getLayoutInflater();
        View v1 = lf.inflate(R.layout.custom_toast, (ViewGroup)findViewById(R.id.customLayout));
        Toast toast = new Toast(MainActivity.this);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.BOTTOM |Gravity.CENTER_HORIZONTAL,0,0);
        toast.setView(v1);
        toast.show();

    }

}

