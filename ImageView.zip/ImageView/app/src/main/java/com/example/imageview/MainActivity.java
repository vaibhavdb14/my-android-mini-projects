package com.example.imageview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Boolean flag = true;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = (ImageView) findViewById(R.id.strawhat);
    }
    public void changeImage(View view){

        if (flag){
            img.setImageResource(R.drawable.zoro);
            flag=false;
        }else {
            img.setImageResource(R.drawable.luffy);
            flag=true;
        }
    }
}