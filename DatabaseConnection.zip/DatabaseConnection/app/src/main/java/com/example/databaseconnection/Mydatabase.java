package com.example.databaseconnection;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Mydatabase extends SQLiteOpenHelper {

    private static final String dbname = "mydb.db";
    public Mydatabase(@Nullable Context context) {
        super(context, dbname/*mydb.db*/, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase sqlDB) {
        String query = "CREATE TABLE Student(Rollno varchar(255) primary key, Name varchar(255))";
        sqlDB.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqlDB, int i, int i1) {
        sqlDB.execSQL("DROP TABLE if exists Student");
        onCreate(sqlDB);
    }

    public String insertData(String roll, String name){
        SQLiteDatabase sqlDB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Rollno", roll);
        cv.put("Name", name);
        long res = sqlDB.insert("Student", null, cv);
        if (res==-1){
            return "Insertion Failed";
        }
        return "Insertion Successful";
    }

    public String fetchData(){
        SQLiteDatabase sqlDB = this.getReadableDatabase();
        String dataCols[] = {"Rollno","Name"};
        StringBuffer str = new StringBuffer();
        Cursor cursor = sqlDB.query("Student", dataCols,null,null, null, null, null);
        while(cursor.moveToNext()){
            String roll = cursor.getString(0);
            String name = cursor.getString(1);
            str.append("\t\t\t"+roll+"      "+name+"\n");
        }
        return str.toString();
    }
    
    public String modifyData(String roll, String name){
        SQLiteDatabase sqlDB = this.getReadableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        String old_roll[]={roll};
        long res = sqlDB.update("Student",cv,"Rollno=?",old_roll);
        if (res==-0){
            return "Updation failed!";
        }else {
            return "Updation Successful!";
        }
    }

    public String removeData(String roll){
        SQLiteDatabase sqlDB = this.getReadableDatabase();
        String data[] = {roll} ;
        int res  = sqlDB.delete("Student", "Rollno=?", data);
        if (res==0){
            return  "Deletion Failed!";
        }else{
            return "Deletion Successful!";
        }
    }
}
