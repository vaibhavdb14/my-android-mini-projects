package com.example.databaseconnection;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText edRoll, edName;
//    ListView listView;
    TextView show;
    SQLiteDatabase sql;
    Mydatabase mdb;
    String strRoll, strName;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mdb = new Mydatabase(this);
        sql = mdb.getWritableDatabase();

        edRoll = (EditText) findViewById(R.id.rollnum);
        edName = (EditText) findViewById(R.id.name);
//        listView = (ListView) findViewById(R.id.listView);
        show = (TextView) findViewById(R.id.show);
    }

    public void addData(View view){
        if (checkData())
                {
                    Toast.makeText(this, "Fields are not supposed to empty", Toast.LENGTH_SHORT).show();
        }else{
            String msg = mdb.insertData(strRoll, strName);
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        }
    }
    public void updateData(View view){

        if (checkData())
        {
            Toast.makeText(this, "Fields are not supposed to empty", Toast.LENGTH_SHORT).show();
        }else{
            String msg = mdb.modifyData(strRoll, strName);
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        }
    }
    public void readData(View view){
//            ArrayList<String> data = new ArrayList<>();
            String fetchedData = mdb.fetchData();
            show.setText(fetchedData);
           // Toast.makeText(this, fetchedData, Toast.LENGTH_SHORT).show();

    }
    public void deleteData(View view){
        strRoll = edRoll.getText().toString().trim();
        if (strRoll.isEmpty())
        {
            Toast.makeText(this, "Roll number field is not supposed to empty", Toast.LENGTH_SHORT).show();
        }else{
           String msg = mdb.removeData(strRoll);
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        }
    }

    public boolean checkData(){
        strRoll = edRoll.getText().toString().trim();
        strName = edName.getText().toString().trim();
        if (strRoll.isEmpty() || strName.isEmpty())
        {
            return true;
        }else{
            return false;
        }
    }

}
