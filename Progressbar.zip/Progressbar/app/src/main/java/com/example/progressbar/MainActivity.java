package com.example.progressbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.*;
import android.view.*;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ProgressBar pb = (ProgressBar)findViewById(R.id.simpleProgressBar);
        Button btn = (Button) findViewById(R.id.startButton);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btn.getText().toString()=="Start"){
                    btn.setText("Stop");
                    pb.setVisibility(View.VISIBLE);
                }else {
                    btn.setText("Start");
                    pb.setVisibility(View.GONE);
                }
            }
        });
    }
}