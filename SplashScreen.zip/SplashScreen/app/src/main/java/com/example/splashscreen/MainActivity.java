package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Thread.sleep(2000);
            installsplashscreen();
        }catch (Exception e){}
        setContentView(R.layout.activity_main);
    }

    private void installsplashscreen() {
    }
}