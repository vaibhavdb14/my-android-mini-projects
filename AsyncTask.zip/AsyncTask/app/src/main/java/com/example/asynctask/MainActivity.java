package com.example.asynctask;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.time.temporal.ValueRange;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.txt);
    }

    public void progress(View view){
        AsyncTaskDemo adt = new AsyncTaskDemo();
        adt.execute();
    }

    class AsyncTaskDemo extends AsyncTask<Void,Integer,String>{

        @Override
        protected String doInBackground(Void... voids) {
            for (int i =1; i<=100; i=i+5){
                try {
                    Thread.sleep(500);
                }catch (Exception e){}

                publishProgress(i);
            }

            return "Finished";
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            textView.setText("AsyncTask will be run in background");
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            textView.setText(s);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            textView.setText(values[0].toString());
        }
    }
}