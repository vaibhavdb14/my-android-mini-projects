package com.example.gridview;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(new ButtonAdapter());
    }

    private class ButtonAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return 15; // Number of buttons
        }
        @Override
        public Object getItem(int position) {
            return null;
        }
        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Button button;
            if (convertView == null) {
                button = new Button(MainActivity.this);
                button.setLayoutParams(new GridView.LayoutParams(GridView.LayoutParams.MATCH_PARENT, GridView.LayoutParams.MATCH_PARENT));
                button.setPadding(8, 8, 8, 8);
            } else {
                button = (Button) convertView;
            }
            button.setText(String.valueOf(position + 1));
            return button;
        }
    }
}



//import androidx.appcompat.app.AppCompatActivity;
//
//import android.annotation.SuppressLint;
//import android.os.Bundle;
//import android.view.*;
//import android.widget.*;
//public class MainActivity extends AppCompatActivity {
//    @Override
//    @SuppressLint("MissingInflatedId")
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        GridView gridView = (GridView) findViewById(R.id.gridView);
//        final Button[] btn = new Button[15];
//        for (int i = 0; i < 15; i++) {
//            btn[i] = new Button(this);
//            btn[i].setText("" + i);
//        }
//        ArrayAdapter<Button> adapter = new ArrayAdapter<Button>(
//                this,
//                R.layout.button_item, // Use the custom layout
//                R.id.grid_button,     // Specify the ID of the Button widget in the layout
//                btn
//        );
//
//        gridView.setAdapter(adapter);
//    }
//}