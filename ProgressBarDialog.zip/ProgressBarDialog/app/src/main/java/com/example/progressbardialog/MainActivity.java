package com.example.progressbardialog;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
//import android.os.Handler;
//import android.os.Message;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void ShowProgress(View view){
        ProgressDialog pd = new ProgressDialog(MainActivity.this);
        pd.setTitle("File Downloading...");
        pd.setMax(100);
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pd.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                int i=0;
                while(i<=100){
                    try{
                        pd.setProgress(i);
                        i+=10;
                        Thread.sleep(200);
                        if(pd.getProgress()==100)
                            pd.dismiss();
                    }catch (Exception e){
                        Log.d(("Name"),"Something Wrong");
                    }
                }
            }
        }).start();
    }
}




//    Second method to do
//    public void ShowProgress(View view){
//        Handler h=new Handler(){
//            public void handleMessage(Message m){
//                pd.incrementProgressBy(10);
//            }
//        };
//        pd=new ProgressDialog(MainActivity.this);
//        pd.setTitle("File downloading....");
//        pd.setProgressStyle(pd.STYLE_HORIZONTAL);
//        pd.show();
//        Thread t=new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try{
//                    while (pd.getProgress()<=100)
//                    {
//                        Thread.sleep(200);
//                        h.sendMessage(h.obtainMessage());
//                        if(pd.getProgress()==100)
//                            pd.dismiss();
//                    }
//                }
//                catch (Exception e)
//                {
//                }
//            }
//        });
//        t.start();
//    }