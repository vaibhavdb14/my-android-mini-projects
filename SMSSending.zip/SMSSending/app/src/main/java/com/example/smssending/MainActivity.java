package com.example.smssending;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.gsm.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    
    EditText edt1, edt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt1 = findViewById(R.id.t1);
        edt2 = findViewById(R.id.t2);
    }
    
    public void sendSMS(View view){
        String text = edt1.getText().toString();
        String num = edt2.getText().toString();
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(num, null, text, null, null);
        Toast.makeText(this, "Sending Mesaage", Toast.LENGTH_SHORT).show();
    }
}