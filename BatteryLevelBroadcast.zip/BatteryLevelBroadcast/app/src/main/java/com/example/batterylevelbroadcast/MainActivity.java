package com.example.batterylevelbroadcast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ProgressBar progressBar;
    TextView textView;

    private BatteryBroadcastReceiver batteryBroadcastReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progress);
        textView = findViewById(R.id.txtview);
        batteryBroadcastReceiver = new BatteryBroadcastReceiver();
    }

    @Override
    protected void onStart() {
        registerReceiver(batteryBroadcastReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(batteryBroadcastReceiver);
        super.onStop();
    }

    public class BatteryBroadcastReceiver extends BroadcastReceiver {
        public BatteryBroadcastReceiver(){}

        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL,0);
            textView.setText("Battery Level : "+level);
            progressBar.setProgress(level);

            if (level>95){
                Toast.makeText(MainActivity.this, "Battery Full", Toast.LENGTH_SHORT).show();
                progressBar.setProgressTintList(ColorStateList.valueOf(Color.GREEN));
            } else if (level<90 && level>=20) {
                Toast.makeText(MainActivity.this, "Battery Status Good", Toast.LENGTH_SHORT).show();
                progressBar.setProgressTintList(ColorStateList.valueOf(Color.YELLOW));
            }else {
                progressBar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                if (level<20 && level>5){
                    Toast.makeText(MainActivity.this, "Battery is Low", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Battery is about to die", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}