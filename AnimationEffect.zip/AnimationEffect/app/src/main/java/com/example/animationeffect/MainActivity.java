package com.example.animationeffect;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.view.animation.*;
public class MainActivity extends AppCompatActivity {

    ImageView img;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = findViewById(R.id.imgview);
    }

    public void blink (View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.blink);
        img.startAnimation(anim);
    }
    public void zoomin (View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoomin);
        img.startAnimation(anim);
    }
    public void zoomout (View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoomout);
        img.startAnimation(anim);
    }
    public void slideup (View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slideup);
        img.startAnimation(anim);
    }
    public void slidedown(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slidedown);
        img.startAnimation(anim);
    }
    public void slideleft (View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slideleft);
        img.startAnimation(anim);
    }
    public void slideright(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slideright);
        img.startAnimation(anim);
    }
    public void moveup(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.moveup);
        img.startAnimation(anim);
    }
    public void movedown(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.movedown);
        img.startAnimation(anim);
    }
    public void moveleft(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.moveleft);
        img.startAnimation(anim);
    }
    public void moveright(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.moveright);
        img.startAnimation(anim);
    }
    public void rotatec(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotatec);
        img.startAnimation(anim);
    }
    public void rotateac(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotateac);
        img.startAnimation(anim);
    }
    public void fadein(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fadein);
        img.startAnimation(anim);
    }
    public void fadeout(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fadeout);
        img.startAnimation(anim);
    }
    public void bounce(View view){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.bounce);
        img.startAnimation(anim);
    }
    public void stopanimation(View view){
        img.clearAnimation();
    }
}