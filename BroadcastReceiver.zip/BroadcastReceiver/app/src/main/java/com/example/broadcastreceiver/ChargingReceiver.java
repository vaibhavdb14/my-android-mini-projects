package com.example.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.util.Log;
import android.widget.Toast;

public class ChargingReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (action != null) {
            if (action.equals(Intent.ACTION_POWER_CONNECTED)) {
                // Charging connected
                Log.d("ChargingReceiver", "Charging connected");
                Toast.makeText(context, "Charging connected", Toast.LENGTH_SHORT).show();
            } else if (action.equals(Intent.ACTION_POWER_DISCONNECTED)) {
                // Charging disconnected
                Log.d("ChargingReceiver", "Charging disconnected");
                Toast.makeText(context, "Charging disconnected", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
