package com.example.broadcastreceiver;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private BroadcastReceiver systemBroadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        systemBroadcastReceiver = new SystemBroadcastReceiver();
        registerSystemBroadcastReceiver();
    }

    private void registerSystemBroadcastReceiver() {

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_BOOT_COMPLETED);
        intentFilter.addAction(Intent.ACTION_POWER_CONNECTED);
        intentFilter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        intentFilter.addAction(Intent.ACTION_BATTERY_LOW);
        intentFilter.addAction(Intent.ACTION_BATTERY_OKAY);
        intentFilter.addAction(Intent.ACTION_TIME_CHANGED);
        registerReceiver(systemBroadcastReceiver, intentFilter);
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(systemBroadcastReceiver);
        super.onDestroy();
    }

    private class SystemBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            String action = intent.getAction();

            if (action != null) {
                switch (action) {
                    case Intent.ACTION_BOOT_COMPLETED:
                        showToast("Boot completed");
                        break;
                    case Intent.ACTION_POWER_CONNECTED:
                        showToast("Power connected");
                        break;
                    case Intent.ACTION_POWER_DISCONNECTED:
                        showToast("Power disconnected");
                        break;
                    case Intent.ACTION_SCREEN_ON:
                        showToast("Screen on");
                        break;
                    case Intent.ACTION_SCREEN_OFF:
                        showToast("Screen Off");
                        break;
                    case Intent.ACTION_BATTERY_LOW:
                        showToast("Battery is low please charge");
                        break;
                    case Intent.ACTION_BATTERY_OKAY:
                        showToast("Battery is full");
                        break;
                    case Intent.ACTION_TIME_CHANGED:
                        showToast("Time changed");
                        break;
                }
            }
        }

        private void showToast(String message) {
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
        }
    }
}