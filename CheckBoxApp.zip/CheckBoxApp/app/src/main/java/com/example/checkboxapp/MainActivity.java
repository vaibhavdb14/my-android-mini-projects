package com.example.checkboxapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.*;
import android.widget.*;


public class MainActivity extends AppCompatActivity {
    CheckBox c1, c2, c3, c4, c5;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        c1 = findViewById(R.id.chk1);
        c2 = findViewById(R.id.chk2);
        c3 = findViewById(R.id.chk3);
        c4 = findViewById(R.id.chk4);
        c5 = findViewById(R.id.chk5);
    }
    public void display(View view){
        StringBuilder result = new StringBuilder();
        result.append("Selected Item : ");
        if(c1.isChecked()){
            result.append("Jalebi ");
        }
        if(c2.isChecked()){
            result.append("KajuKatli ");
        }
        if(c3.isChecked()){
            result.append("Kalakand ");
        }
        if(c4.isChecked()){
            result.append("Nankhatai ");
        }
        if(c5.isChecked()){
            result.append("Modak ");
        }
        if(result.length()==16){
            result.replace(0, 17, "No Item is Selected");
        }
        Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
    }
}