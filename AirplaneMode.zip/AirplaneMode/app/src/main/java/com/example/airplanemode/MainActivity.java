package com.example.airplanemode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    AirplaneMode airplaneMode = new AirplaneMode();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter in = new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        registerReceiver(airplaneMode, in);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(airplaneMode);
    }
    
    protected  class AirplaneMode extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {

            if (isAirplaneModeOn(context.getApplicationContext())){
                Toast.makeText(context, "Airpane mode is on", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(context, "Airpane mode is Off", Toast.LENGTH_SHORT).show();
            }
        }

        public boolean isAirplaneModeOn(Context context) {

            return Settings.System.getInt(context.getContentResolver(),Settings.Global.AIRPLANE_MODE_ON, 0)!=0;
        }
    }


}